streamlit
yfinance
requests
matplotlib
plotly
alpha_vantage
